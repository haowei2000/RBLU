from pyecharts import options as opts
from pyecharts.charts import Line


def draw_line_chart(
    data,
    labels,
    title="Line Chart",
    x_axis_name="X-Axis",
    y_axis_name="Y-Axis",
):
    """
    Draw a line chart with multiple lists.

    :param data: List of lists, where each inner list represents a series of data points.
    :param labels: List of labels for each series.
    :param title: Title of the chart.
    :param x_axis_name: Name of the x-axis.
    :param y_axis_name: Name of the y-axis.
    """
    line = Line()
    for series, label in zip(data, labels):
        line.add_xaxis(list(range(len(series))))
        line.add_yaxis(label, series)

    line.set_global_opts(
        title_opts=opts.TitleOpts(title=title),
        xaxis_opts=opts.AxisOpts(name=x_axis_name),
        yaxis_opts=opts.AxisOpts(name=y_axis_name),
    )

    return line


# Example usage
data = [[10, 20, 30, 40, 50], [15, 25, 35, 45, 55], [20, 30, 40, 50, 60]]
labels = ["Series 1", "Series 2", "Series 3"]

chart = draw_line_chart(data, labels)
chart.render("line_chart.html")
